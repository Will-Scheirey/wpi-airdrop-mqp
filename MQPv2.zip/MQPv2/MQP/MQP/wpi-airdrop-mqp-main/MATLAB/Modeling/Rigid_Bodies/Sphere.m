classdef Sphere < Rigid_Body
    %SPHEREOBJECT Summary of this class goes here
    %   Detailed explanation goes here

    properties
        R
        A
        P_attach_B
        Cd_0
    end

    methods
        function obj = Sphere(m, R, drag)
            I_XX = 2/5*m*R^2; % Moment of inertia of a sphere [kg m^2]
            I_YY = I_XX;      % Moment of inertia of a sphere [kg m^2]
            I_ZZ = I_XX;      % Moment of inertia of a sphere [kg m^2]
            
            I_XY = 0;         % Moment of inertia of a sphere [kg m^2]
            I_XZ = 0;         % Moment of inertia of a sphere [kg m^2]
            I_YZ = 0;         % Moment of inertia of a sphere [kg m^2]
            
            % Inertia Tensor
            I = [
             I_XX, -I_XY, -I_XZ;
            -I_XY,  I_YY, -I_YZ;
            -I_XZ, -I_YZ,  I_ZZ;
            ];
            obj = obj@Rigid_Body(m, I);
            obj.R = R;
            obj.A = pi*R^2;

            obj.P_attach_B = [R; 0; 0];

            if nargin == 3
                if drag
                    obj.Cd_0 = 0.5;
                else
                    obj.Cd_0 = 0;
                end
            else
                obj.Cd_0 = 0.5;
            end
        end

        function S_out = S(obj, ~); S_out = obj.A; end
        function Cd_out = Cd(obj, ~); Cd_out = obj.Cd_0; end
    end
end