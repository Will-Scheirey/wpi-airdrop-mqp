function v = adjusted_rate_of_fall(Rof,average_pressure_altitude, average_temperature)
    v = (Rof *average_temperature)/average_pressure_altitude ; 
end