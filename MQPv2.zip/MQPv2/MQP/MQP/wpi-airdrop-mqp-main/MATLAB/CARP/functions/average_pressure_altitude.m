function p = average_pressure_altitude(pressure_altitude, drop_altitude)
    p = pressure_altitude - (drop_altitude)/2;
end