function t = time_of_fall(stabilization_altitude, adjusted_rate_of_fall)
    t = stabilization_altitude/adjusted_rate_of_fall;
end