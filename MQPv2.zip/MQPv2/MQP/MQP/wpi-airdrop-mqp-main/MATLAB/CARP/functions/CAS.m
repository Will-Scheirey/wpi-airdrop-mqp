function v =CAS(indicated_airspeed,correctionFactor)
% Convert indicated airspeed to calibrated airspeed
v = indicated_airspeed * correctionFactor; 
end