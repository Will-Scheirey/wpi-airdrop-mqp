function v = equivalent_airspeed(CAS,p_o,p)
    v = CAS*sqrt(p_o/p);
end