function alt = altitude_above_PI(true_altitude, PI)
    alt = true_altitude - PI;
end