function P = pressure_altitude(true_altitude, pressure_altitude_variation)
    P = true_altitude + pressure_altitude_variation;
end