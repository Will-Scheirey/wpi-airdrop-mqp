function v = ground_speed(wind_speed, true_airspeed)
    v = wind_speed + true_airspeed;
end