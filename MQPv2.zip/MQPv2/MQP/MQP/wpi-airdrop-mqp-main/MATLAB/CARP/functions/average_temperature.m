function t = average_temperature(true_altitude_temperature, surface_temperature)
    t = (true_altitude_temperature + surface_temperature) / 2;
end