function temp = Temperature(h)
    temp = 286.16 + -6.5e-3 * h;
end

