function kg = lb2kg(lb)
    kg = lb * 0.453592;
end