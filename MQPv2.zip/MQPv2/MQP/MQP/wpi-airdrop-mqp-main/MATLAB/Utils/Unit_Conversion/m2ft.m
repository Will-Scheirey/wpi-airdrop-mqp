function ft = m2ft(m)
    ft = m * 3.28084;
end