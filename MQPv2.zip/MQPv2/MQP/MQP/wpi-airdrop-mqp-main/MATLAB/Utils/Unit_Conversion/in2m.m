function m = in2m(in)
    m = in * 0.0254;
end