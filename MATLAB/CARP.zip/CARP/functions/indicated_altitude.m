function alt = indicated_altitude(corrected_drop_altitude, terrain_elevation)
alt = corrected_drop_altitude + terrain_elevation;
end