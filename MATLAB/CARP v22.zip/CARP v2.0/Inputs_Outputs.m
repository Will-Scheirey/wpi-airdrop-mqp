close all; clear all; clc;

% ========================================================================
%  CARP (Computed Air Release Point) CALCULATOR
%  Displays all inputs and calculated outputs
% ========================================================================

fprintf('\n');
fprintf('====================================================================\n');
fprintf('           CARP PARAMETER CALCULATOR\n');
fprintf('====================================================================\n\n');

% INPUT PARAMETERS
fprintf('INPUT PARAMETERS:\n');
fprintf('--------------------------------------------------------------------\n');

% Basic Drop Parameters
drop_altitude = 25000;              % ft above ground level
terrain_elevation = 200;            % ft elevation of highest point in DZ
dz_altimeter = 29.50;               % altimeter setting (inHg)
true_altitude_temperature = 20;     % Celsius
indicated_airspeed = 130;           % knots
correctionFactor = 1.02;            % correction factor for aircraft instrumentation
surface_temperature = 20;           % Celsius temperature at the DZ

% Air Density Parameters
p_o = 0.0765;                       % standard air density (lb/ft^3)
p = 0.034;                          % actual air density at altitude (lb/ft^3)

% Parachute Ballistics Data
RoF = 10;                           % ft/s rate of fall
PI = 200;                           % ft AGL (Point of Impact)
VD = 180;                           % ft vertical distance
TFC = 15;                           % sec time of fall constant
exit_time = 3;                      % sec from parachute ballistics
DQ = 2;                             % sec deceleration quotient

% Wind Parameters
ballistic_wind = 15;                % knots - wind affecting load descent
drop_altitude_wind = 20;            % knots - wind at drop altitude
wind_speed = 20;                    % ft/s - wind speed affecting airspeed

% Navigation Parameters
DZ_course = 270;                    % deg - DZ centerline course
drift_correction = 5;               % deg - heading correction

fprintf('  Drop Altitude:              %d ft AGL\n', drop_altitude);
fprintf('  Terrain Elevation:          %d ft\n', terrain_elevation);
fprintf('  DZ Altimeter Setting:       %.2f inHg\n', dz_altimeter);
fprintf('  Temperature at Altitude:    %d °C\n', true_altitude_temperature);
fprintf('  Surface Temperature:        %d °C\n', surface_temperature);
fprintf('  Indicated Airspeed:         %d knots\n', indicated_airspeed);
fprintf('  Correction Factor:          %.2f\n', correctionFactor);
fprintf('  Rate of Fall:               %d ft/s\n', RoF);
fprintf('  Ballistic Wind:             %d knots\n', ballistic_wind);
fprintf('  Drop Altitude Wind:         %d knots\n', drop_altitude_wind);
fprintf('  DZ Course:                  %d°\n', DZ_course);
fprintf('  Drift Correction:           %d°\n', drift_correction);
fprintf('\n');

%INPUTS
% Basic Drop Parameters
drop_altitude = 25000;              % ft above ground level
terrain_elevation = 200;            % ft elevation of highest point in DZ
dz_altimeter = 29.50;               % altimeter setting (inHg)
true_altitude_temperature = 20;     % Celsius
indicated_airspeed = 130;           % knots
correctionFactor = 1.02;            % correction factor for aircraft instrumentation
surface_temperature = 20;           % Celsius temperature at the DZ

% Air Density Parameters
p_o = 0.0765;                       % standard air density (lb/ft^3)
p = 0.034;                          % actual air density at altitude (lb/ft^3)

% Parachute Ballistics Data
RoF = 10;                           % ft/s rate of fall
PI = 200;                           % ft AGL (Point of Impact)
VD = 180;                           % ft vertical distance
TFC = 15;                           % sec time of fall constant
exit_time = 3;                      % sec from parachute ballistics
DQ = 2;                             % sec deceleration quotient

% Wind Parameters
ballistic_wind = 15;                % knots - wind affecting load descent
drop_altitude_wind = 20;            % knots - wind at drop altitude
wind_speed = 20;                    % ft/s - wind speed affecting airspeed

% Navigation Parameters
DZ_course = 270;                    % deg - DZ centerline course
drift_correction = 5;               % deg - heading correction

% CALCULATED OUTPUTS
fprintf('CALCULATED OUTPUTS:\n');
fprintf('--------------------------------------------------------------------\n');

% Altitude Calculations
true_alt = true_altitude(drop_altitude, terrain_elevation);
pav = pressure_altitude_variation(dz_altimeter, true_alt);
pressure_alt = pressure_altitude(true_alt, pav);
corrected_drop_alt = corrected_drop_altitude(drop_altitude, true_altitude_temperature, pressure_alt);
indicated_alt = indicated_altitude(corrected_drop_alt, terrain_elevation);
alt_above_PI = altitude_above_PI(true_alt, PI);
stab_altitude = stabilization_altitude(VD, alt_above_PI);

fprintf('\nAltitude Calculations:\n');
fprintf('  True Altitude:              %d ft\n', true_alt);
fprintf('  Pressure Altitude:          %d ft\n', pressure_alt);
fprintf('  Corrected Drop Altitude:    %d ft\n', corrected_drop_alt);
fprintf('  Indicated Altitude:         %d ft\n', indicated_alt);
fprintf('  Altitude Above PI:          %d ft\n', alt_above_PI);
fprintf('  Stabilization Altitude:     %d ft\n', stab_altitude);

% Airspeed Calculations
cas = CAS(indicated_airspeed, correctionFactor);
eas = equivalent_airspeed(cas, p_o, p);
tas = true_airspeed(eas, pressure_alt, true_altitude_temperature);
gs = ground_speed(wind_speed, tas);

fprintf('\nAirspeed Calculations:\n');
fprintf('  Calibrated Airspeed (CAS):  %.2f knots\n', cas);
fprintf('  Equivalent Airspeed (EAS):  %.2f knots\n', eas);
fprintf('  True Airspeed (TAS):        %.2f knots\n', tas);
fprintf('  Ground Speed:               %.2f knots\n', gs);

% Temperature and Pressure Calculations
avg_temp = average_temperature(true_altitude_temperature, surface_temperature);
avg_pressure_alt = average_pressure_altitude(pressure_alt, drop_altitude);

fprintf('\nAverage Conditions:\n');
fprintf('  Average Temperature:        %.2f °C\n', avg_temp);
fprintf('  Average Pressure Altitude:  %.2f ft\n', avg_pressure_alt);

% Time and Distance Calculations
adj_rof = adjusted_rate_of_fall(RoF, avg_pressure_alt, avg_temp);
tof = time_of_fall(stab_altitude, adj_rof);
total_tof = total_time_of_fall(TFC, tof);
ftt = forward_travel_time(DQ, exit_time);
ftd = forward_travel_distance(ftt, gs);
drift_eff = drift_effect(ballistic_wind, total_tof);

fprintf('\nTime of Fall Calculations:\n');
fprintf('  Adjusted Rate of Fall:      %.2f ft/s\n', adj_rof);
fprintf('  Time of Fall:               %.2f sec\n', tof);
fprintf('  Total Time of Fall:         %.2f sec\n', total_tof);
fprintf('  Forward Travel Time:        %.2f sec\n', ftt);

fprintf('\nDistance Calculations:\n');
fprintf('  Forward Travel Distance:    %.2f yards\n', ftd);
fprintf('  Drift Effect:               %.2f yards\n', drift_eff);

% Navigation Calculations
dz_heading_val = DZ_course + drift_correction;

fprintf('\nNavigation Calculations:\n');
fprintf('  DZ Heading:                 %.2f°\n', dz_heading_val);

fprintf('\n====================================================================\n');
fprintf('                    END OF CALCULATIONS\n');
fprintf('====================================================================\n\n');